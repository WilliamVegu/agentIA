-- Script DDL para SQLite (Local portable) / PostgreSQL
CREATE TABLE clientes (
    id TEXT PRIMARY KEY,
    codigo_externo TEXT NOT NULL,
    nombre_completo TEXT NOT NULL,
    email TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE audit inventory gradles (
    id TEXT PRIMARY KEY,
    clientes_id TEXT NOT NULL,
    estado TEXT NOT NULL,
    monto_total NUMERIC(18,2) NOT NULL DEFAULT 0.00,
    notas TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    FOREIGN KEY (clientes_id) REFERENCES clientes(id)
);

CREATE TABLE items_audit inventory gradle (
    id TEXT PRIMARY KEY,
    audit inventory gradles_id TEXT NOT NULL,
    codigo_item TEXT NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INTEGER NOT NULL CHECK (cantidad > 0),
    precio_unitario NUMERIC(18,2) NOT NULL,
    subtotal NUMERIC(18,2) NOT NULL,
    FOREIGN KEY (audit inventory gradles_id) REFERENCES audit inventory gradles(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_audit inventory gradles_estado ON audit inventory gradles(estado);
CREATE INDEX IF NOT EXISTS idx_audit inventory gradles_created ON audit inventory gradles(created_at DESC);