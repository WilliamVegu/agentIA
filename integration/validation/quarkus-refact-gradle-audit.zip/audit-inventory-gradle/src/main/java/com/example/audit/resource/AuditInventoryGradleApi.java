package com.example.audit.resource;

import com.example.audit.dto.*;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import java.util.UUID;

/**
 * Interfaz generada dinámicamente a partir del Contrato OpenAPI 3.1 revisado.
 * Implementa el enfoque Contract-First de Quarkus 3.x.
 */
@Path("/api/v1")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "audit-inventory-gradle", description = "Operaciones de audit-inventory-gradle")
public interface AuditInventoryGradleApi {

        @Path("/warehouse/items")
    @GET
    @Operation(summary = "Operación GET en /warehouse/items")
    Response findWarehouseItems();
}
