package com.example.audit.repository;

import com.example.audit.model.AuditInventoryGradl;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Optional;
import java.util.Objects;

@ApplicationScoped
public class AuditInventoryGradlRepository implements PanacheRepositoryBase<AuditInventoryGradl, String> {

    public List<AuditInventoryGradl> findByStatus(String status) {
        return list("estado", status);
    }

    public Optional<AuditInventoryGradl> findActiveById(String id) {
        return find("id", id).firstResultOptional();
    }
}
