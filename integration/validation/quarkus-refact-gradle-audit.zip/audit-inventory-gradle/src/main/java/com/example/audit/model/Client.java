package com.example.audit.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Entidad de persistencia Panache Active Record / JPA.
 * Tabla: clientes
 * Microservicio: audit-inventory-gradle
 */
@Entity
@Table(name = "clientes")
public class Client extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    public String id;

    @Column(nullable = false)
    public String codigoExterno;

    @Column(nullable = false)
    public String nombreCompleto;

    @Column
    public String email;

    @Column(nullable = false)
    public Instant createdAt;

    public Client() {}
}
