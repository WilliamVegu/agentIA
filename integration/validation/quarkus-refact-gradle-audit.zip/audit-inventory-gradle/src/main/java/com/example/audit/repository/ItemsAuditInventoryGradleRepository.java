package com.example.audit.repository;

import com.example.audit.model.ItemsAuditInventoryGradle;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Optional;
import java.util.Objects;

@ApplicationScoped
public class ItemsAuditInventoryGradleRepository implements PanacheRepositoryBase<ItemsAuditInventoryGradle, String> {

    public List<ItemsAuditInventoryGradle> findByStatus(String status) {
        return list("estado", status);
    }

    public Optional<ItemsAuditInventoryGradle> findActiveById(String id) {
        return find("id", id).firstResultOptional();
    }
}
