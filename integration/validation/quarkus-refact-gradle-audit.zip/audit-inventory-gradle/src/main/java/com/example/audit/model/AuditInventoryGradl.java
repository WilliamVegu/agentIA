package com.example.audit.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Entidad de persistencia Panache Active Record / JPA.
 * Tabla: audit inventory gradles
 * Microservicio: audit-inventory-gradle
 */
@Entity
@Table(name = "audit inventory gradles")
public class AuditInventoryGradl extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    public String id;

    @Column(nullable = false)
    public String clientesId;

    @Column(nullable = false)
    public String estado;

    @Column(nullable = false)
    public BigDecimal montoTotal;

    @Column
    public String nota;

    @Column(nullable = false)
    public Instant createdAt;

    @Column(nullable = false)
    public Instant updatedAt;

    public AuditInventoryGradl() {}
}
