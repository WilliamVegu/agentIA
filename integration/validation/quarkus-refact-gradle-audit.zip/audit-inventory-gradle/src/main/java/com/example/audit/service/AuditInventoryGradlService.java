package com.example.audit.service;

import com.example.audit.model.AuditInventoryGradl;
import com.example.audit.repository.AuditInventoryGradlRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class AuditInventoryGradlService {

    @Inject
    AuditInventoryGradlRepository repository;

    public List<AuditInventoryGradl> listAll(int page, int size) {
        return repository.findAll().page(page, size).list();
    }

    public AuditInventoryGradl getById(String id) {
        return repository.findByIdOptional(id)
            .orElseThrow(() -> new NotFoundException("AuditInventoryGradl no encontrado con ID: " + id));
    }

    @Transactional
    public AuditInventoryGradl create(AuditInventoryGradl entity) {
        repository.persist(entity);
        return entity;
    }

    @Transactional
    public void delete(String id) {
        boolean deleted = repository.deleteById(id);
        if (!deleted) {
            throw new NotFoundException("No se encontró AuditInventoryGradl para eliminar con ID: " + id);
        }
    }
}
