# 📖 Catálogo de Endpoints de la API (audit-inventory-gradle)
Generado a partir del contrato **OpenAPI 3.1** aprobado por **Audit**.

## Matriz de Operaciones REST

| Método HTTP | Ruta / Endpoint | Descripción / Resumen |
|:-----------:|:----------------|:----------------------|
| `GET` | `/warehouse/items` | Operación GET en /warehouse/items |

---

## Observabilidad y Diagnóstico de Fábrica
* **Liveness Probe:** `GET /q/health/live` (Indica si el contenedor está vivo).
* **Readiness Probe:** `GET /q/health/ready` (Valida conexión a base de datos y dependencias).
* **Prometheus Metrics:** `GET /q/metrics` (Métricas de runtime JVM, latencia y throughput).
* **OpenAPI 3.1 Spec:** `GET /q/openapi` (Especificación en JSON/YAML).
