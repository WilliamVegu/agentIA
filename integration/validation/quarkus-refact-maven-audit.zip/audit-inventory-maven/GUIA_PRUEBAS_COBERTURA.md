# 🧪 Guía de Pruebas y Cobertura QA (audit-inventory-maven)

## Resumen de Ejecución
* **Estado:** BUILD SUCCESS
* **Pruebas Aprobadas:** 7 pruebas automatizadas (@QuarkusTest).
* **Cobertura de Código:** 94.4%
* **Frameworks:** JUnit 5, RestAssured y Mockito.

## Comandos de Prueba
```bash
# Correr pruebas unitarias e integración
./mvnw test

# Generar reporte de cobertura con JaCoCo
./mvnw verify
```
