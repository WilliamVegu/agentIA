# AUDIT-INVENTORY-MAVEN ⚡
> Microservicio autónomo desarrollado con **Quarkus 3.15 LTS** y **Java 21**.
> Equipo responsable: **Audit** | Grupo: `com.example.audit`

---

## 📋 Resumen del Microservicio
Manage inventory products, stock levels and warehouse movements for each item.

* **Enfoque de diseño:** Contract-First (OpenAPI 3.1 congelado).
* **Patrón Arquitectónico:** LAYERED.
* **Base de datos:** PostgreSQL.
* **Seguridad:** JWT (SmallRye JWT).
* **Modo de Generación:** Continuo (Sin límite).

---

## 🚀 Arranque Rápido en Modo Desarrollo
Para iniciar el microservicio con recarga en caliente (*Live Coding* de Quarkus):

```bash
./mvnw quarkus:dev
```

* **Swagger UI / OpenAPI:** `http://localhost:8080/q/swagger-ui`
* **Quarkus Dev UI:** `http://localhost:8080/q/dev`
* **Health Probes:** `http://localhost:8080/q/health`
* **Métricas Prometheus:** `http://localhost:8080/q/metrics`

---

## 🧪 Ejecución de Pruebas Unitarias e Integración
```bash
./mvnw test
```
