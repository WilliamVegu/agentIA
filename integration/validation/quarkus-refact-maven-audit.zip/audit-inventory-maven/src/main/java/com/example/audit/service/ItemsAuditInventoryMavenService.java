package com.example.audit.service;

import com.example.audit.model.ItemsAuditInventoryMaven;
import com.example.audit.repository.ItemsAuditInventoryMavenRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class ItemsAuditInventoryMavenService {

    @Inject
    ItemsAuditInventoryMavenRepository repository;

    public List<ItemsAuditInventoryMaven> listAll(int page, int size) {
        return repository.findAll().page(page, size).list();
    }

    public ItemsAuditInventoryMaven getById(String id) {
        return repository.findByIdOptional(id)
            .orElseThrow(() -> new NotFoundException("ItemsAuditInventoryMaven no encontrado con ID: " + id));
    }

    @Transactional
    public ItemsAuditInventoryMaven create(ItemsAuditInventoryMaven entity) {
        repository.persist(entity);
        return entity;
    }

    @Transactional
    public void delete(String id) {
        boolean deleted = repository.deleteById(id);
        if (!deleted) {
            throw new NotFoundException("No se encontró ItemsAuditInventoryMaven para eliminar con ID: " + id);
        }
    }
}
