package com.example.audit.repository;

import com.example.audit.model.ItemsAuditInventoryMaven;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Optional;
import java.util.Objects;

@ApplicationScoped
public class ItemsAuditInventoryMavenRepository implements PanacheRepositoryBase<ItemsAuditInventoryMaven, String> {

    public List<ItemsAuditInventoryMaven> findByStatus(String status) {
        return list("estado", status);
    }

    public Optional<ItemsAuditInventoryMaven> findActiveById(String id) {
        return find("id", id).firstResultOptional();
    }
}
