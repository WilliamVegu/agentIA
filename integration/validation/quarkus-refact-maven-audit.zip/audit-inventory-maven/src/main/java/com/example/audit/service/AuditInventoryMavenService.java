package com.example.audit.service;

import com.example.audit.model.AuditInventoryMaven;
import com.example.audit.repository.AuditInventoryMavenRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class AuditInventoryMavenService {

    @Inject
    AuditInventoryMavenRepository repository;

    public List<AuditInventoryMaven> listAll(int page, int size) {
        return repository.findAll().page(page, size).list();
    }

    public AuditInventoryMaven getById(String id) {
        return repository.findByIdOptional(id)
            .orElseThrow(() -> new NotFoundException("AuditInventoryMaven no encontrado con ID: " + id));
    }

    @Transactional
    public AuditInventoryMaven create(AuditInventoryMaven entity) {
        repository.persist(entity);
        return entity;
    }

    @Transactional
    public void delete(String id) {
        boolean deleted = repository.deleteById(id);
        if (!deleted) {
            throw new NotFoundException("No se encontró AuditInventoryMaven para eliminar con ID: " + id);
        }
    }
}
