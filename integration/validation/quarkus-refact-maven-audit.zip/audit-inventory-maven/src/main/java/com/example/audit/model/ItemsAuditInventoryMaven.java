package com.example.audit.model;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Entidad de persistencia Panache Active Record / JPA.
 * Tabla: items_audit inventory maven
 * Microservicio: audit-inventory-maven
 */
@Entity
@Table(name = "items_audit inventory maven")
public class ItemsAuditInventoryMaven extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    public String id;

    @Column(nullable = false)
    public String auditInventoryMavensId;

    @Column(nullable = false)
    public String codigoItem;

    @Column(nullable = false)
    public String descripcion;

    @Column(nullable = false)
    public Integer cantidad;

    @Column(nullable = false)
    public BigDecimal precioUnitario;

    @Column(nullable = false)
    public BigDecimal subtotal;

    public ItemsAuditInventoryMaven() {}
}
