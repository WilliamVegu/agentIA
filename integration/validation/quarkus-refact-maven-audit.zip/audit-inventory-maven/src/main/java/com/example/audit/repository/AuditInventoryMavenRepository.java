package com.example.audit.repository;

import com.example.audit.model.AuditInventoryMaven;
import io.quarkus.hibernate.orm.panache.PanacheRepositoryBase;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.List;
import java.util.Optional;
import java.util.Objects;

@ApplicationScoped
public class AuditInventoryMavenRepository implements PanacheRepositoryBase<AuditInventoryMaven, String> {

    public List<AuditInventoryMaven> findByStatus(String status) {
        return list("estado", status);
    }

    public Optional<AuditInventoryMaven> findActiveById(String id) {
        return find("id", id).firstResultOptional();
    }
}
