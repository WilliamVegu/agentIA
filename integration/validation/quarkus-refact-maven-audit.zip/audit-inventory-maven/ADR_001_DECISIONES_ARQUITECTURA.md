# ADR-001: Decisiones de Arquitectura para audit-inventory-maven

## Estado
**APROBADO** por Audit y el Agente Arquitecto.

## Contexto
El microservicio `audit-inventory-maven` requiere implementar las reglas de negocio descritas:
> "Manage inventory products, stock levels and warehouse movements for each item."

## Decisiones Técnicas
1. **Patrón Arquitectónico:** Se seleccionó el patrón **LAYERED**.
2. **Framework Base:** Quarkus 3.15 LTS (Java 21 LTS) por su optimización para microservicios y soporte nativo GraalVM.
3. **Persistencia:** Quarkus Hibernate ORM con Panache y migraciones automáticas con Flyway.
4. **Motor de Datos:** PostgreSQL.
5. **Seguridad:** JWT (SmallRye JWT).

## Consecuencias
* Alta mantenibilidad y aislamiento de capas.
* Compatibilidad con despliegues en contenedores Kubernetes de bajo consumo de memoria.
